import 'package:flutter/material.dart';

enum ServiceProviderCategory { maintenance, electrical, moving, plumbing }

class ServiceProvider {
  final String id;
  final String nameAr;
  final String nameEn;
  final String tradeAr;
  final String tradeEn;
  final String cityAr;
  final String cityEn;
  final String taskCount;
  final String rating;
  final String completionRate;
  final String responseTime;
  final String phone;
  final ServiceProviderCategory category;
  final IconData icon;
  final bool available;
  final bool verified;
  final bool featured;
  final String featureAr;
  final String featureEn;

  const ServiceProvider({
    required this.id,
    required this.nameAr,
    required this.nameEn,
    required this.tradeAr,
    required this.tradeEn,
    required this.cityAr,
    required this.cityEn,
    required this.taskCount,
    required this.rating,
    required this.completionRate,
    required this.responseTime,
    required this.phone,
    required this.category,
    required this.icon,
    required this.available,
    required this.verified,
    required this.featured,
    required this.featureAr,
    required this.featureEn,
  });
}

const serviceProviders = <ServiceProvider>[
  ServiceProvider(
    id: 'PRO-1042',
    nameAr: 'مؤسسة التبريد المتقن للصيانة',
    nameEn: 'Perfect Cooling Maintenance',
    tradeAr: 'صيانة مكيفات وتبريد مركزي',
    tradeEn: 'AC and central cooling maintenance',
    cityAr: 'الرياض - حي الياسمين (نطاق 15 كم)',
    cityEn: 'Riyadh - Al Yasmin (15 km radius)',
    taskCount: '184',
    rating: '4.9',
    completionRate: '98.6%',
    responseTime: '14',
    phone: '+966500001042',
    category: ServiceProviderCategory.maintenance,
    icon: Icons.inventory_2_outlined,
    available: true,
    verified: true,
    featured: true,
    featureAr: 'صيانة مكيفات وتبريد مركزي',
    featureEn: 'AC and central cooling maintenance',
  ),
  ServiceProvider(
    id: 'PRO-1038',
    nameAr: 'مؤسسة الإتقان للكهرباء الشاملة',
    nameEn: 'Al-Itqan Complete Electrical',
    tradeAr: 'أعمال كهرباء، تمديدات ووحدات ذكية',
    tradeEn: 'Electrical work, wiring, and smart systems',
    cityAr: 'الرياض - حي الملقا',
    cityEn: 'Riyadh - Al Malqa',
    taskCount: '310',
    rating: '4.8',
    completionRate: '96.4%',
    responseTime: '18',
    phone: '+966500001038',
    category: ServiceProviderCategory.electrical,
    icon: Icons.electrical_services_outlined,
    available: true,
    verified: true,
    featured: false,
    featureAr: 'أعمال كهرباء، تمديدات ووحدات ذكية',
    featureEn: 'Electrical work, wiring, and smart systems',
  ),
  ServiceProvider(
    id: 'PRO-1024',
    nameAr: 'شركة المسار السريع للنقل والتركيب',
    nameEn: 'Fast Track Moving & Setup',
    tradeAr: 'نقل وتركيب أثاث وخدمات نقل متكاملة',
    tradeEn: 'Furniture moving, setup, and full moving services',
    cityAr: 'الرياض - حي الصحافة',
    cityEn: 'Riyadh - Al Sahafah',
    taskCount: '95',
    rating: '4.6',
    completionRate: '93.2%',
    responseTime: '22',
    phone: '+966500001024',
    category: ServiceProviderCategory.moving,
    icon: Icons.local_shipping_outlined,
    available: false,
    verified: true,
    featured: false,
    featureAr: 'نقل وتركيب أثاث بعمالة كاملة',
    featureEn: 'Moving and furniture setup with a full crew',
  ),
  ServiceProvider(
    id: 'PRO-1016',
    nameAr: 'المركز الهندسي لخدمات التكييف',
    nameEn: 'Engineering Center HVAC Services',
    tradeAr: 'فحص وصيانة وإصلاح وحدات التكييف',
    tradeEn: 'AC inspection, maintenance, and repair',
    cityAr: 'الرياض - حي النخيل',
    cityEn: 'Riyadh - Al Nakheel',
    taskCount: '120',
    rating: '4.7',
    completionRate: '95.8%',
    responseTime: '16',
    phone: '+966500001016',
    category: ServiceProviderCategory.maintenance,
    icon: Icons.home_repair_service_outlined,
    available: true,
    verified: true,
    featured: true,
    featureAr: 'فحص وصيانة وإصلاح دورية',
    featureEn: 'Inspection, maintenance, and routine repair',
  ),
];

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/di/injection_container.dart';
import '../../../../core/utils/currency_formatter.dart';
import '../controllers/bank_accounts/bank_accounts_cubit.dart';
import '../controllers/bank_accounts/bank_accounts_state.dart';
import '../controllers/expenses/expense_requests_cubit.dart';
import '../controllers/expenses/expense_requests_state.dart';
import '../../domain/entities/expense_request_entity.dart';
import '../../../../l10n/app_localizations.dart';
import '../../../../core/widgets/app_snack_bar.dart';
import '../../../../core/widgets/finance_dialogs.dart';
import '../utils/finance_localizer.dart';
import '../widgets/finance_navigation.dart';

class ExpensesManagementScreen extends StatelessWidget {
  const ExpensesManagementScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => BankAccountsCubit(
        getBankAccountsUseCase: sl(),
        getBankAccountEditRequestsUseCase: sl(),
        submitBankAccountEditRequestUseCase: sl(),
      )..loadBankAccounts(),
      child: BlocProvider(
        create: (context) => ExpenseRequestsCubit(
          getExpenseRequestsUseCase: sl(),
          submitExpenseRequestUseCase: sl(),
        )..loadRequests(),
        child: const _ExpensesManagementScreenContent(),
      ),
    );
  }
}

class _ExpensesManagementScreenContent extends StatefulWidget {
  const _ExpensesManagementScreenContent();

  @override
  State<_ExpensesManagementScreenContent> createState() =>
      _ExpensesManagementScreenState();
}

class _ExpensesManagementScreenState
    extends State<_ExpensesManagementScreenContent> {
  final TextEditingController _amountController = TextEditingController();
  final TextEditingController _reasonController = TextEditingController();
  String _selectedPaymentMethod = '';
  String? _attachmentName;

  @override
  void dispose() {
    _amountController.dispose();
    _reasonController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    return Directionality(
      textDirection: l10n.localeName.startsWith('ar')
          ? TextDirection.rtl
          : TextDirection.ltr,
      child: Scaffold(
        backgroundColor: AppColors.backgroundLight,
        appBar: FinancePageAppBar(
          title: l10n.expensesManagementTitle,
          subtitle: l10n.financialDepartment,
          showBackButton: true,
          onBackPressed: () => Navigator.pop(context),
        ),
        body: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // 1. Amount Card
              _buildSectionCard(
                icon: Icons.payments_outlined,
                title: l10n.amountToDisburse,
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  decoration: BoxDecoration(
                    color: AppColors.surfaceLight,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: AppColors.cardBorder,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(l10n.currencyEgy,
                            style:
                                const TextStyle(fontWeight: FontWeight.bold)),
                      ),
                      Expanded(
                        child: TextFormField(
                          controller: _amountController,
                          keyboardType: const TextInputType.numberWithOptions(
                              decimal: true),
                          textAlign: TextAlign.left,
                          style: const TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                              color: AppColors.textPrimary),
                          decoration: const InputDecoration(
                            border: InputBorder.none,
                            isDense: true,
                            contentPadding: EdgeInsets.zero,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),

              // 2. Payment Method Card
              _buildSectionCard(
                icon: Icons.account_balance_wallet_outlined,
                title: l10n.accountAndPaymentChannel,
                child: BlocBuilder<BankAccountsCubit, BankAccountsState>(
                  builder: (context, state) {
                    if (state is BankAccountsLoading) {
                      return const Center(
                          child: CircularProgressIndicator(
                              color: AppColors.primaryDark));
                    } else if (state is BankAccountsLoaded) {
                      final accounts = state.accounts;
                      if (accounts.isEmpty) {
                        return Center(child: Text(l10n.noAccountsAvailable));
                      }

                      // Select first by default if not set
                      if (!accounts
                          .any((a) => a.id == _selectedPaymentMethod)) {
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          setState(() {
                            _selectedPaymentMethod = accounts.first.id;
                          });
                        });
                      }

                      return Column(
                        children: accounts.map((account) {
                          return Padding(
                            padding: const EdgeInsets.only(bottom: 10),
                            child: _buildPaymentOption(
                              id: account.id,
                              title: FinanceLocalizer.localizeBankName(
                                  context, account.bankName),
                              subtitle: account.iban,
                              balanceLabel: account.accountType.contains('ضمان')
                                  ? l10n.escrowBalanceLabel
                                  : l10n.currentLedgerBalanceLabel,
                              balanceValue:
                                  '${CurrencyFormatter.format(account.balance, includeCurrency: false)} ${l10n.currencyEgy}',
                            ),
                          );
                        }).toList(),
                      );
                    }
                    return const SizedBox();
                  },
                ),
              ),
              const SizedBox(height: 16),

              // 3. Document Category Card
              _buildSectionCard(
                icon: Icons.assignment_outlined,
                title: l10n.expenseCategoryAndDocuments,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(l10n.detailedExpenseReason,
                        style: const TextStyle(
                            fontSize: 11, color: AppColors.textSecondary)),
                    const SizedBox(height: 8),
                    TextFormField(
                      key: const ValueKey('expenseReasonField'),
                      controller: _reasonController,
                      maxLines: 2,
                      decoration: InputDecoration(
                        hintText: l10n.expenseDetailsHint,
                        hintStyle: const TextStyle(
                            fontSize: 12, color: AppColors.textMuted),
                        filled: true,
                        fillColor: AppColors.surfaceLight,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide.none,
                        ),
                        contentPadding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 12),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(l10n.invoiceSupportDocument,
                        style: const TextStyle(
                            fontSize: 11, color: AppColors.textSecondary)),
                    const SizedBox(height: 8),
                    InkWell(
                      onTap: () {
                        setState(() {
                          _attachmentName = _attachmentName == null
                              ? 'invoice_receipt.pdf'
                              : null;
                        });
                        AppSnackBar.showInfo(
                          context,
                          _attachmentName == null
                              ? l10n.expenseDocumentRemoved
                              : '${l10n.expenseDocumentAttached}: $_attachmentName',
                        );
                      },
                      borderRadius: BorderRadius.circular(12),
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        decoration: BoxDecoration(
                          color: _attachmentName != null
                              ? Colors.green.shade50
                              : AppColors.surfaceLight,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: _attachmentName != null
                                ? Colors.green.shade300
                                : Colors.transparent,
                          ),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              _attachmentName != null
                                  ? Icons.check_circle
                                  : Icons.attach_file,
                              color: _attachmentName != null
                                  ? Colors.green.shade700
                                  : AppColors.info,
                              size: 16,
                            ),
                            const SizedBox(width: 8),
                            Flexible(
                              child: Text(
                                _attachmentName != null
                                    ? '${l10n.expenseAttachedPrefix}: $_attachmentName (${l10n.expenseRemoveDocumentAction})'
                                    : l10n.attachDocumentOptional,
                                style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                    color: _attachmentName != null
                                        ? Colors.green.shade800
                                        : Colors.blue.shade800),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // 4. Governance Alert
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppColors.cardBorder),
                  boxShadow: [
                    BoxShadow(
                        color: Colors.black.withValues(alpha: 0.02),
                        blurRadius: 4,
                        offset: const Offset(0, 2)),
                  ],
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                          color: AppColors.surfaceLight,
                          borderRadius: BorderRadius.circular(8)),
                      child: const Icon(Icons.gavel,
                          color: AppColors.textSecondary, size: 20),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(l10n.strictFinancialDisbursementGovernance,
                              style: const TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  color: AppColors.textPrimary)),
                          const SizedBox(height: 4),
                          Text(
                            l10n.disbursementGovernanceNote,
                            style: TextStyle(
                                fontSize: 10,
                                color: Colors.grey.shade600,
                                height: 1.4),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              // 5. Actions
              BlocBuilder<ExpenseRequestsCubit, ExpenseRequestsState>(
                builder: (context, state) => ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primaryDark,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                    elevation: 0,
                  ),
                  icon: state.isSubmitting
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : const Icon(Icons.send_outlined, size: 18),
                  onPressed: state.isSubmitting
                      ? null
                      : () => _submitExpenseRequest(context, l10n),
                  label: Text(
                    state.isSubmitting
                        ? l10n.expenseRequestSubmitting
                        : l10n.approvePaymentOrder,
                    style: const TextStyle(
                        fontSize: 13, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              BlocBuilder<ExpenseRequestsCubit, ExpenseRequestsState>(
                builder: (context, state) {
                  if (state.errorMessage != null) {
                    return Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Text(
                        l10n.expenseRequestSendFailed,
                        style: const TextStyle(
                            color: AppColors.danger, fontSize: 12),
                      ),
                    );
                  }
                  if (state.requests.isEmpty) return const SizedBox.shrink();

                  return Column(
                    children: [
                      const SizedBox(height: 16),
                      ...state.requests.reversed.map(
                        (request) => Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: _buildExpenseRequestCard(request, l10n),
                        ),
                      ),
                    ],
                  );
                },
              ),
              const SizedBox(height: 12),
              OutlinedButton(
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppColors.textSecondary,
                  backgroundColor: AppColors.surfaceLight,
                  side: const BorderSide(color: Colors.transparent),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: () => Navigator.pop(context),
                child: Text(l10n.cancelPaymentOrder,
                    style: const TextStyle(
                        fontSize: 12, fontWeight: FontWeight.bold)),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _submitExpenseRequest(
      BuildContext context, AppLocalizations l10n) async {
    final rawAmount = _amountController.text
        .trim()
        .replaceAll(',', '')
        .replaceAll('٬', '')
        .replaceAll('٫', '.');
    final amount = double.tryParse(rawAmount);
    if (amount == null || !amount.isFinite || amount <= 0) {
      _showExpenseMessage(l10n.expenseAmountInvalid, AppColors.warning);
      return;
    }

    final reason = _reasonController.text.trim();
    if (reason.isEmpty) {
      _showExpenseMessage(l10n.expenseReasonRequired, AppColors.warning);
      return;
    }

    final bankState = context.read<BankAccountsCubit>().state;
    if (bankState is! BankAccountsLoaded || bankState.accounts.isEmpty) {
      _showExpenseMessage(l10n.noAccountsAvailable, AppColors.warning);
      return;
    }

    final selectedAccounts = bankState.accounts
        .where((account) => account.id == _selectedPaymentMethod)
        .toList(growable: false);
    if (selectedAccounts.isEmpty) {
      _showExpenseMessage(l10n.noAccountsAvailable, AppColors.warning);
      return;
    }
    final selectedAccount = selectedAccounts.first;

    final confirmed = await FinanceDialogs.showApprovalDialog(
      context,
      title: l10n.expenseConfirmTitle,
      description: l10n.expenseConfirmDescription,
      confirmText: l10n.approvePaymentOrder,
    );
    if (!confirmed || !mounted || !context.mounted) return;

    final result = await context.read<ExpenseRequestsCubit>().submitRequest(
          amount: amount,
          bankAccountId: selectedAccount.id,
          reason: reason,
          attachmentName: _attachmentName,
        );
    if (!mounted || !context.mounted) return;

    result.fold(
      (_) =>
          _showExpenseMessage(l10n.expenseRequestSendFailed, AppColors.danger),
      (_) {
        _amountController.clear();
        _reasonController.clear();
        setState(() => _attachmentName = null);
        _showExpenseMessage(l10n.expenseRequestSent, AppColors.success);
      },
    );
  }

  void _showExpenseMessage(String message, Color backgroundColor) {
    if (backgroundColor == AppColors.success) {
      AppSnackBar.showSuccess(context, message);
      return;
    }
    if (backgroundColor == AppColors.danger) {
      AppSnackBar.showError(context, message);
      return;
    }
    AppSnackBar.showInfo(context, message);
  }

  Widget _buildExpenseRequestCard(
      ExpenseRequestEntity request, AppLocalizations l10n) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.warningLight,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.warningBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.hourglass_top_rounded,
                  color: AppColors.warningDark, size: 18),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  l10n.expenseRequestPendingStatus,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    color: AppColors.warningDark,
                  ),
                ),
              ),
              Text(
                '${l10n.expenseRequestNumber}: ${request.id}',
                textDirection: TextDirection.ltr,
                style: const TextStyle(fontSize: 10, color: Colors.black54),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text('${l10n.expenseRequestAmount}: '
              '${CurrencyFormatter.format(request.amount)}'),
          const SizedBox(height: 4),
          Text(FinanceLocalizer.localizeBankName(context, request.bankName)),
          const SizedBox(height: 4),
          Text(request.reason),
          if (request.attachmentName != null) ...[
            const SizedBox(height: 4),
            Text('${l10n.expenseAttachedPrefix}: ${request.attachmentName}'),
          ],
        ],
      ),
    );
  }

  Widget _buildSectionCard(
      {required IconData icon, required String title, required Widget child}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.cardBorder),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.02),
              blurRadius: 4,
              offset: const Offset(0, 2)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: AppColors.info, size: 18),
              const SizedBox(width: 8),
              Expanded(
                child: Text(title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                        color: AppColors.textPrimary)),
              ),
            ],
          ),
          const SizedBox(height: 16),
          child,
        ],
      ),
    );
  }

  Widget _buildPaymentOption({
    required String id,
    required String title,
    required String subtitle,
    required String balanceLabel,
    required String balanceValue,
  }) {
    bool isSelected = _selectedPaymentMethod == id;
    return GestureDetector(
      onTap: () => setState(() => _selectedPaymentMethod = id),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: isSelected ? Colors.blue.shade50 : AppColors.surfaceLight,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
              color: isSelected ? Colors.blue.shade200 : Colors.transparent),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          color: isSelected
                              ? AppColors.textPrimary
                              : Colors.black87)),
                  const SizedBox(height: 4),
                  Text(subtitle,
                      style: const TextStyle(
                          fontSize: 10, color: AppColors.textSecondary),
                      textDirection: TextDirection.ltr,
                      textAlign: TextAlign.right),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Flexible(
                        child: Text(balanceLabel,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                                fontSize: 10, color: AppColors.textSecondary)),
                      ),
                      const SizedBox(width: 4),
                      Text(balanceValue,
                          style: const TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                              color: AppColors.textPrimary)),
                    ],
                  ),
                ],
              ),
            ),
            Container(
              width: 20,
              height: 20,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                    color: isSelected
                        ? AppColors.primaryDark
                        : AppColors.textMuted,
                    width: isSelected ? 6 : 1.5),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
